#!/bin/bash
URL="https://meridian-fairlend-production.up.railway.app/?platform=mac"
DATA_DIR="$HOME/Library/Application Support/RinDristiAI/AppProfile"
mkdir -p "$DATA_DIR"
if [ -x "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" ]; then
  exec "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" --app="$URL" --user-data-dir="$DATA_DIR" --new-window --class="RinDristi FairLend AI" --no-first-run --no-default-browser-check
elif [ -x "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" ]; then
  exec "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --app="$URL" --user-data-dir="$DATA_DIR" --new-window --class="RinDristi FairLend AI" --no-first-run --no-default-browser-check
elif [ -x "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser" ]; then
  exec "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser" --app="$URL" --user-data-dir="$DATA_DIR" --new-window --class="RinDristi FairLend AI" --no-first-run --no-default-browser-check
elif [ -x "/Applications/Safari.app/Contents/MacOS/Safari" ]; then
  exec open -n -a "/Applications/Safari.app" "$URL"
else
  exec open "$URL"
fi
