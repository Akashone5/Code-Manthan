#!/bin/bash
URL="https://meridian-fairlend-production.up.railway.app/?platform=mac"
if [ -x "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" ]; then
  exec "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --app="$URL" --no-first-run --no-default-browser-check
elif [ -x "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" ]; then
  exec "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" --app="$URL" --no-first-run --no-default-browser-check
elif [ -x "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser" ]; then
  exec "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser" --app="$URL" --no-first-run --no-default-browser-check
else
  exec open "$URL"
fi
